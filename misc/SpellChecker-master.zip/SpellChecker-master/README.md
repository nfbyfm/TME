# Spell-Checking-with-Hunspell-and-Qt
Qt + hunspell example code

Put to git from here:
https://wiki.qt.io/Spell-Checking-with-Hunspell

To ease the compilation and testing.
